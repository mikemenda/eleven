/**
 * createClub.mjs
 *
 * Creates a new club doc in the Firestore clubs collection.
 * Default: dry-run (read-only). Use --write to create the doc.
 *
 * Every club created by this script writes gameId, so the club
 * automatically appears in the frontend save selector without
 * any frontend code change.
 *
 * Game resolution:
 *   --game="FC 26"   looks up the game by title in the games collection (preferred)
 *   --gameId=<id>    explicit Firestore document ID (fallback)
 *
 * Either --game or --gameId is required. Clubs created without a gameId
 * are permanently invisible in the selector — this script no longer
 * allows that to happen.
 *
 * Usage:
 *   cd /Users/MichaelMenda/Documents/Mike/1Apps/eleven/1Repo
 *
 *   # Dry-run (always run first):
 *   node scripts/createClub.mjs \
 *     --name="FC Montverd" \
 *     --game="FC 26" \
 *     --manager="Pep Guardiola" \
 *     --formation="4-3-3" \
 *     --league="Premier League"
 *
 *   # Write (only after reviewing dry-run output):
 *   node scripts/createClub.mjs \
 *     --name="FC Montverd" \
 *     --game="FC 26" \
 *     --manager="Pep Guardiola" \
 *     --formation="4-3-3" \
 *     --league="Premier League" \
 *     --write
 *
 * Optional metadata:
 *   --manager     Manager name     default: ""
 *   --formation   Tactical shape   default: ""
 *   --league      Starting league  default: ""
 *   --crestColor  Hex color        default: "#D4AF37"
 *
 * What it writes (clubs collection):
 *   name · gameId · manager · formation · league · crestColor
 *   seasonsLogged · trophyCount · createdAt
 *
 * What it does NOT touch:
 *   seasons · players · seasonStats · matches · transfers · opponents · games
 *
 * After running --write, note the club ID printed in the output.
 * All subsequent commands for this club require --clubId=<id>.
 * All existing clubs also require --clubId once multiple clubs exist:
 *
 *   node scripts/importSeason.mjs --season=S1 --file=data/uploads/montverd/S1.json --clubId=<new-id>
 *   node scripts/validateDataHealth.mjs --clubId=<new-id>
 *   node scripts/auditAndPatchTeamLogos.mjs --season=S1 --clubId=<new-id>
 *
 * serviceAccountKey.json must be at the project root (never committed).
 */

import { createRequire } from 'module'
import { readFileSync }  from 'fs'
import { resolve, dirname } from 'path'
import { fileURLToPath } from 'url'

const require    = createRequire(import.meta.url)
const admin      = require('firebase-admin')
const __dirname  = dirname(fileURLToPath(import.meta.url))
const KEY_PATH   = resolve(__dirname, '../serviceAccountKey.json')

// ─── CLI ─────────────────────────────────────────────────────────────────────

const WRITE = process.argv.includes('--write')

const args = {}
for (const arg of process.argv.slice(2)) {
  const eq = arg.indexOf('=')
  if (eq !== -1) args[arg.slice(2, eq)] = arg.slice(eq + 1)
  else           args[arg.replace(/^--/, '')] = true
}

// ─── Firebase ─────────────────────────────────────────────────────────────────

function initFirebase() {
  if (admin.apps.length) return admin.firestore()
  let sa
  try { sa = JSON.parse(readFileSync(KEY_PATH, 'utf8')) }
  catch (e) {
    console.error(`\n✗ Could not read serviceAccountKey.json: ${e.message}`)
    console.error('  Place your Firebase service account key at the project root.\n')
    process.exit(1)
  }
  admin.initializeApp({ credential: admin.credential.cert(sa) })
  return admin.firestore()
}

// ─── Game resolution ──────────────────────────────────────────────────────────

async function resolveGame(db) {
  // Explicit gameId takes precedence
  if (args.gameId) {
    const snap = await db.collection('games').doc(args.gameId).get()
    if (!snap.exists) {
      console.error(`\n✗ No game found with id: "${args.gameId}"\n`)
      process.exit(1)
    }
    return { id: snap.id, ...snap.data() }
  }

  // Lookup by title
  if (args.game) {
    const snap  = await db.collection('games').get()
    const all   = snap.docs.map(d => ({ id: d.id, ...d.data() }))
    const query = args.game.toLowerCase().trim()
    const matches = all.filter(g =>
      (g.title || g.name || g.label || '').toLowerCase().trim() === query
    )

    if (matches.length === 0) {
      const available = all.map(g => `"${g.title || g.name || g.id}"`).join(', ')
      console.error(`\n✗ No game found matching "${args.game}".`)
      console.error(`  Available: ${available || '(none — games collection is empty)'}`)
      console.error('  Check the title or use --gameId=<id> instead.\n')
      process.exit(1)
    }

    if (matches.length > 1) {
      console.error(`\n✗ Multiple games matched "${args.game}" — use --gameId=<id> to be explicit:`)
      matches.forEach(g => console.error(`     ${g.id}  "${g.title || g.name}"`))
      console.error()
      process.exit(1)
    }

    return matches[0]
  }

  // Neither provided
  console.error('\n✗ Game is required. Pass either:')
  console.error('     --game="FC 26"   (preferred — looks up by title)')
  console.error('     --gameId=<id>    (explicit Firestore document ID)')
  console.error()
  console.error('  Clubs created without a gameId are permanently invisible')
  console.error('  in the frontend save selector. This script requires a game.\n')
  process.exit(1)
}

// ─── Helpers ──────────────────────────────────────────────────────────────────

function normName(s) { return (s || '').trim().toLowerCase() }

function header(t) {
  console.log('\n' + '─'.repeat(62))
  console.log('  ' + t)
  console.log('─'.repeat(62))
}

function row(label, value) {
  console.log(`  ${label.padEnd(18)} ${value}`)
}

// ─── Main ─────────────────────────────────────────────────────────────────────

async function main() {

  // ── Validate CLI ────────────────────────────────────────────────────────────
  if (!args.name) {
    console.error('\n✗ --name is required  (e.g. --name="FC Montverd")\n')
    process.exit(1)
  }

  if (!args.game && !args.gameId) {
    console.error('\n✗ --game or --gameId is required.')
    console.error('  Every club must be linked to a game so it appears in the selector.')
    console.error('  Example: --game="FC 26"\n')
    process.exit(1)
  }

  const clubName = args.name.trim()

  if (!clubName) {
    console.error('\n✗ --name cannot be empty\n')
    process.exit(1)
  }

  // Resolve optional metadata with defaults
  const manager    = typeof args.manager    === 'string' ? args.manager    : ''
  const formation  = typeof args.formation  === 'string' ? args.formation  : ''
  const league     = typeof args.league     === 'string' ? args.league     : ''
  const crestColor = typeof args.crestColor === 'string' ? args.crestColor : '#D4AF37'

  console.log('\n══════════════════════════════════════════════════════════════')
  console.log(`  createClub — ${WRITE ? '⚠️  WRITE MODE' : 'DRY RUN (default)'}`)
  console.log(`  Name    : ${clubName}`)
  console.log(`  Game    : ${args.game || `(explicit gameId: ${args.gameId})`}`)
  console.log('══════════════════════════════════════════════════════════════')

  const db = initFirebase()

  // ── Resolve game ─────────────────────────────────────────────────────────────
  header('Game Resolution')
  console.log()

  const game = await resolveGame(db)
  console.log(`  ✓ Game resolved`)
  console.log(`    id    : ${game.id}`)
  console.log(`    title : ${game.title || game.name || '(no title field)'}`)

  // ── Load existing clubs ───────────────────────────────────────────────────────
  header('Existing Clubs')
  console.log()

  const snap = await db.collection('clubs').get()
  const existingClubs = snap.docs.map(d => ({ id: d.id, ...d.data() }))

  if (existingClubs.length === 0) {
    console.log('  (no clubs found in Firestore — this will be the first)')
  } else {
    for (const club of existingClubs) {
      const gid   = club.gameId ? ` gameId:${club.gameId}` : ' ⚠ no gameId'
      const sameGame = club.gameId === game.id ? ' ← same game' : ''
      console.log(`  ✓  ${club.id}  "${club.name}"${gid}${sameGame}`)
    }
  }

  // ── Name collision check ──────────────────────────────────────────────────────
  const duplicate = existingClubs.find(c => normName(c.name) === normName(clubName))
  if (duplicate) {
    console.error(`\n✗ A club named "${clubName}" already exists (id: ${duplicate.id}).`)
    console.error('  No action taken. Use the existing club ID with --clubId.\n')
    process.exit(1)
  }

  // ── Write plan ────────────────────────────────────────────────────────────────
  header('Write Plan')
  console.log()

  const clubDoc = {
    name:          clubName,
    gameId:        game.id,
    manager:       manager,
    formation:     formation,
    league:        league,
    crestColor:    crestColor,
    seasonsLogged: 0,
    trophyCount:   0,
    createdAt:     admin.firestore.FieldValue.serverTimestamp(),
  }

  console.log('  Will create 1 doc in: clubs/')
  console.log()
  row('name',          `"${clubDoc.name}"`)
  row('gameId',        clubDoc.gameId)
  row('manager',       `"${clubDoc.manager}"`)
  row('formation',     `"${clubDoc.formation}"`)
  row('league',        `"${clubDoc.league}"`)
  row('crestColor',    `"${clubDoc.crestColor}"`)
  row('seasonsLogged', String(clubDoc.seasonsLogged))
  row('trophyCount',   String(clubDoc.trophyCount))
  row('createdAt',     '<server timestamp>')
  console.log()
  console.log('  Collections NOT touched:')
  console.log('    seasons · players · seasonStats · matches · transfers · opponents · games')

  // ── Dry-run exit ─────────────────────────────────────────────────────────────
  if (!WRITE) {
    console.log('\n══════════════════════════════════════════════════════════════')
    console.log('  DRY RUN COMPLETE — no data was written.')
    console.log(`  Run with --write to create "${clubName}".`)
    console.log('══════════════════════════════════════════════════════════════\n')
    return
  }

  // ── Write ─────────────────────────────────────────────────────────────────────
  header('Creating Club')
  console.log()

  const clubRef = db.collection('clubs').doc()
  const clubId  = clubRef.id

  try {
    await clubRef.set(clubDoc)
  } catch (err) {
    console.error(`\n  ✗ Firestore write FAILED. No club was created.`)
    console.error(`  Error: ${err.message}\n`)
    process.exit(1)
  }

  // ── Verify ────────────────────────────────────────────────────────────────────
  const verify = await db.collection('clubs').doc(clubId).get()
  if (!verify.exists) {
    console.error('\n  ✗ Post-write verification FAILED — doc not found after write.\n')
    process.exit(1)
  }

  const written = verify.data()
  const verifyFields = ['name', 'gameId', 'manager', 'formation', 'league', 'crestColor']
  let verifyPass = true

  for (const f of verifyFields) {
    if (written[f] !== clubDoc[f]) {
      console.log(`  ✗ ${f}: written "${written[f]}" ≠ expected "${clubDoc[f]}"`)
      verifyPass = false
    }
  }

  console.log('\n══════════════════════════════════════════════════════════════')
  if (verifyPass) {
    console.log('  ✅  CLUB CREATED')
    console.log()
    console.log(`  Name      : ${written.name}`)
    console.log(`  Club ID   : ${clubId}`)
    console.log(`  gameId    : ${written.gameId}`)
    console.log()
    console.log('  ── Copy this ID — required for all subsequent commands ──')
    console.log()
    console.log('  Import S1 (dry-run first):')
    console.log(`    node scripts/importSeason.mjs --season=S1 --file=data/uploads/<save>/S1.json --clubId=${clubId}`)
    console.log()
    console.log('  Health check:')
    console.log(`    node scripts/validateDataHealth.mjs --clubId=${clubId}`)
    console.log()
    console.log('  ── Existing clubs now require --clubId too ──')
    console.log()
    existingClubs.forEach(c => {
      console.log(`  ${c.name.padEnd(22)} --clubId=${c.id}`)
    })
  } else {
    console.log('  ⚠   Club created but post-write verification found mismatches.')
    console.log('  Check Firestore directly and re-run the dry-run to diagnose.')
  }
  console.log('══════════════════════════════════════════════════════════════\n')
}

main().catch(err => { console.error('\nFatal error:', err); process.exit(1) })
